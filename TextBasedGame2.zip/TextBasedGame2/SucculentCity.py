# A Violet Bern
# CS 499 Artifact 2 & 3

import sqlite3
import os
from random import randint

# function to delete database - should only be used for error handling and testing
def drop_database():
    db_file = 'SucculentPlayers.db'
    if os.path.exists(db_file):
        os.remove(db_file)
        print(f"{db_file} has been deleted.")
    else:
        print(f"{db_file} does not exist.")


# Initializes database and tables for game
def initialize_database():
    connection = sqlite3.connect('SucculentPlayers.db')
    cursor = connection.cursor()

    # Create tables if they don't exist
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS player_game_details (
        player_id INTEGER PRIMARY KEY, 
        current_room TEXT,
        inventory TEXT,
        FOREIGN KEY (player_id) REFERENCES users(id)
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS weapons (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        description TEXT
    )
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS player_inventory (
        player_id INTEGER,
        weapon_id INTEGER,
        FOREIGN KEY (player_id) REFERENCES users(id),
        FOREIGN KEY (weapon_id) REFERENCES weapons(id)
    )
    ''')

    connection.commit()
    connection.close()


# Adds game weapons to the inventory
def add_weapon(name, description):
    connection = sqlite3.connect('SucculentPlayers.db')
    cursor = connection.cursor()
    # Check if the weapon already exists
    cursor.execute('SELECT * FROM weapons WHERE name = ?', (name,))
    # Adds item if it doesn't exist in database
    if cursor.fetchone() is None:
        cursor.execute('INSERT INTO weapons (name, description) VALUES (?, ?)', (name, description))
        print(f'Added weapon: {name}')

    connection.commit()
    connection.close()


# User registration process with username and password
def register_user(username, password):
    connection = sqlite3.connect('SucculentPlayers.db')
    cursor = connection.cursor()

    try:
        cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
        connection.commit()
        print("User registered successfully!")
    except sqlite3.IntegrityError:
        print("Username already exists. Please choose a different username.")
    finally:
        connection.close()


# User login process - compares against users database table
def login_user(username, password):
    connection = sqlite3.connect('SucculentPlayers.db')
    cursor = connection.cursor()

    cursor.execute('SELECT id FROM users WHERE username = ? AND password = ?', (username, password))
    user = cursor.fetchone()

    connection.close()
    if user:
        return user[0]  # Return the user ID
    else:
        print("Invalid username or password.")
        return None


# Loads player details from database tables - should be done right before game play
def load_player_details(player_id):
    connection = sqlite3.connect('SucculentPlayers.db')
    cursor = connection.cursor()

    cursor.execute('''
        SELECT gd.current_room, GROUP_CONCAT(w.name) AS inventory
        FROM player_game_details gd
        LEFT JOIN player_inventory pi ON gd.player_id = pi.player_id
        LEFT JOIN weapons w ON pi.weapon_id = w.id
        WHERE gd.player_id = ?
        GROUP BY gd.player_id
        ''', (player_id,))

    row = cursor.fetchone()

    if row:
        current_room = row[0]
        inventory_items = row[1].split(',') if row[1] else []
        return current_room, inventory_items
    else:
        return 'Great Hall', []  # Default starting state if none exists

    connection.commit()
    connection.close()


# Saves player's game details when the player quits the game
def save_player_details(player_id, current_room, inventory_items):
    connection = sqlite3.connect('SucculentPlayers.db')
    cursor = connection.cursor()

    # Update the player's current room
    cursor.execute('''
    INSERT INTO player_game_details (player_id, current_room, inventory)
    VALUES (?, ?, ?)
    ON CONFLICT(player_id) DO UPDATE SET current_room = ?, inventory = ?
    ''', (player_id, current_room, ','.join(inventory_items), current_room, ','.join(inventory_items)))

    # Clears existing database inventory for the player
    cursor.execute('DELETE FROM player_inventory WHERE player_id = ?', (player_id,))

    # Adds the new inventory items for the player
    for item in inventory_items:
        cursor.execute('SELECT id FROM weapons WHERE name = ?', (item,))
        weapon_id = cursor.fetchone()
        if weapon_id:
            cursor.execute('INSERT INTO player_inventory (player_id, weapon_id) VALUES (?, ?)', (player_id, weapon_id[0]))

    connection.commit()
    connection.close()


# How health and damage is dealth at the boss fight of the game
def health(soldier_bug, inventory_items):
    health_value = 6
    hits = 6
    death = False
    ant_health = 8

    if len(inventory_items) < 6:
        print('Oh no!')
        print('You did not collect all 6 items and were unable to defend yourself.')
        print('The Argentine Ants have consumed you.')
        print('You have failed The Silver Queen and the citizens of Succulent City.')
        print('Game Over')
        exit()

    while death is False or hits != 0:
        # When there is no soldier bug this is how damage is given to player and boss
        if soldier_bug == 0:
            damage_taken = randint(1, 6)
            health_value = health_value - damage_taken
            damage_given = randint(1, 6)
            ant_health = ant_health - damage_given
            hits -= 1
            if health_value <= 0:
                print('*Spray spray spray*')
                print('You have failed the Silver Queen and the citizens of Succulent City.')
                print('Game Over')
                exit()
            elif ant_health <= 0:
                print('*Spray spray spray*')
                print('You have defeated the Argentine Ants and saved the citizens of Succulent City!')
                print('The Silver Queen thanks you with riches beyond imagination.')
                print('Congratulations!')
                exit()
        # When there is a soldier bug this is how the damage is given to the player / boss
        else:
            damage_taken = randint(1, 6)
            health_value = health_value - (damage_taken / 2)
            damage_given = randint(1, 6)
            ant_health = ant_health - (damage_given * 2)
            if health_value <= 0:
                print('*Spray spray spray*')
                print('You have failed the Silver Queen and the citizens of Succulent City.')
                print('Game Over')
                exit()
            elif ant_health <= 0:
                print('*Spray spray spray*')
                print('You have defeated the Argentine Ants and saved the citizens of Succulent City!')
                print('The Silver Queen thanks you with riches beyond imagination.')
                print('Congratulations!')
                exit()


def main():
    current_room = 'Great Hall'  # set beginning room to Great Hall
    inventory_items = []         # set inventory items to an empty list

    # Commenting out - will permanently delete data so only use for testing
    # drop_database()
    initialize_database()

    # Dictionary containing rooms and directions
    rooms = {
        'Great Hall': {'South': 'Greenhouse', 'North': 'Bathhouse', 'East': 'Apothecary Room', 'West': 'Western Foyer',
                       'Item': 'no items'},
        'Greenhouse': {'North': 'Great Hall', 'East': 'Horticultural Room', 'Item': 'Insect Killing Granules'},
        'Horticultural Room': {'West': 'Greenhouse', 'Item': 'Horticultural Oil'},
        'Bathhouse': {'South': 'Great Hall', 'East': 'Basement', 'Item': 'Insecticidal Soap Bubbles'},
        'Western Foyer': {'East': 'Great Hall', 'Item': 'Rubbing Alcohol'},
        'Apothecary Room': {'North': 'Solar Room', 'West': 'Great Hall', 'Item': 'White Vinegar'},
        'Solar Room': {'South': 'Apothecary Room', 'Item': 'Mighty Spray Bottle'},
        'Basement': {'West': 'Bathhouse', 'Item': 'Argentine Ants'}
    }

    # Login / Registration loop
    while True:
        action = input("Do you want to (1) Register or (2) Login? (Enter 1 or 2): ")
        if action == '1':
            username = input("Enter a username: ")
            password = input("Enter a password: ")
            register_user(username, password)
            continue
        elif action == '2':
            username = input("Enter your username: ")
            password = input("Enter your password: ")
            player_id = login_user(username, password)
            if player_id:
                break  # Exit the loop if login is successful

    # Welcomes user to the game and shows user game instructions / commands
    def game_instructions():
        print('Welcome to Succulent City Adventure Game!')
        print('You are the Black Knight. The Silver Queen needs you to save Succulent City from the '
              'Argentine Ants.')
        print("To win the game, collect 6 items and defeat the Argentine Ants.")
        print('Move commands: go South, go North, go East, go West')
        print('Add to inventory command: get (item name)')
        print('Quit game command: quit')
        print('-'*20)

    # Allows the user to move between rooms in the game
    def moves(direction, room='Great Hall', soldier_bug = 0):   # Calculates user's movement between rooms
        if room == 'Great Hall':               # Calculates which room is the user's current room
            if direction == 'South':
                print("It's so warm in here.")
                return rooms[room]['South']   # returns user's new room
            elif direction == 'North':
                print('*Bloop Bloop Pop*')
                return rooms[room]['North']
            elif direction == 'East':
                print("Wow, there's a lot of bottles in here.")
                return rooms[room]['East']
            elif direction == 'West':
                return rooms[room]['West']
        elif room == 'Greenhouse':
            # The soldier bug is in the Greenhouse
            soldier_bug = 1
            print('You found a soldier bug to help protect you')
            if direction == 'North':
                return rooms[room]['North'], soldier_bug
            elif direction == 'South':
                print('You walked into a wall.')
                print()
                print('Please choose a different direction.')
                return room, soldier_bug
            elif direction == 'East':
                print('Wow, there is a lot of plant stuff in here.')
                return rooms[room]['East']
            elif direction == 'West':
                print('You walked into a wall.')
                print()
                print('Please choose a different direction.')
                return room
        elif room == 'Horticultural Room':
            if direction == 'North':
                print("Oof, that's a wall.")
                print()
                print('Please enter a different direction.')
                return room
            elif direction == 'South':
                print('You see a pretty view but you cannot go out the window.')
                print()
                print('Please choose a different direction.')
                return room
            elif direction == 'East':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room
            elif direction == 'West':
                print("It's still hot in here.")
                return rooms[room]['West']
        elif room == 'Bathhouse':
            if direction == 'North':
                print("Ugh, you got sprayed with water from the shower.")
                print()
                print('Please choose a different direction.')
                return room
            elif direction == 'South':
                print('You are in', end=' ')
                return rooms[room]['South']
            elif direction == 'East':            # room is basement and user either wins or loses the game
                health(soldier_bug, inventory_items)
            elif direction == 'West':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room
        elif room == 'Western Foyer':
            if direction == 'North':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room
            elif direction == 'South':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room
            elif direction == 'East':
                print('You are in', end=' ')
                return rooms[room]['East']
            elif direction == 'West':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room
        elif room == 'Apothecary Room':
            if direction == 'North':
                print('The sky looks so beautiful in here.')
                return rooms[room]['North']
            elif direction == 'South':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room
            elif direction == 'East':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room
            elif direction == 'West':
                return rooms[room]['West']
        elif room == 'Solar Room':
            if direction == 'North':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room
            elif direction == 'South':
                return rooms[room]['South']
            elif direction == 'East':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room
            elif direction == 'West':
                print("Oof, that's a wall.")
                print()
                print("Please choose a different direction.")
                return room

    def get_item(room, item):                           # adds items to user's inventory
        if room == 'Greenhouse':                        # calculates user's current room
            if item == 'Insect Killing Granules':       # checks that user input is the correct item
                return rooms['Greenhouse']['Item']      # returns the room item
            elif item != 'Insect Killing Granules':     # if user input is not the correct item
                print('Please enter a valid command.')  # outputs error message
                return ()
        elif room == 'Horticultural Room':
            if item == 'Horticultural Oil':
                return rooms['Horticultural Room']['Item']
            elif item != 'Horticultural Oil':
                print('Please enter a valid command.')
                return ()
        elif room == 'Bathhouse':
            if item == 'Insecticidal Soap Bubbles':
                return rooms['Bathhouse']['Item']
            elif item != 'Insecticidal Soap Bubbles':
                print('Please enter a valid command.')
                return ()
        elif room == 'Western Foyer':
            if item == 'Rubbing Alcohol':
                return rooms['Western Foyer']['Item']
            elif item != 'Rubbing Alcohol':
                print('Please enter a valid command.')
                return ()
        elif room == 'Apothecary Room':
            if item == 'White Vinegar':
                return rooms['Apothecary Room']['Item']
            elif item != 'White Vinegar':
                print('Please enter a valid command.')
                return ()
        elif room == 'Solar Room':
            if item == 'Mighty Spray Bottle':
                return rooms['Solar Room']['Item']
            elif item != 'Mighty Spray Bottle':
                print('Please enter a valid command.')
                return ()

    # Gets inventory items from SQL tables for player
    def get_inventory(player_id):
        connection = sqlite3.connect('SucculentPlayers.db')
        cursor = connection.cursor()
        cursor.execute('''
        SELECT weapons.name FROM player_inventory
        JOIN weapons ON player_inventory.weapon_id = weapons.id
        WHERE player_inventory.player_id = ?
        ''', (player_id,))
        items = cursor.fetchall()
        connection.close()
        return [item[0] for item in items]

    # Displays the user's current room, inventory items, and what item they can see in their room
    def show_status(player_id):
        print('You are in the', current_room)
        print('Inventory:', inventory_items)
        print('You see {}'.format(rooms[current_room]['Item']))
        print('-' * 20)

    # After login the welcome and play prompt is displayed
    game_instructions()  # call game_instructions function to run
    play_response = input('Would you like to play? (Y/N)\033[1m \n').upper()  # converts user input to bold
    print('\033[0m')  # converts text back to light
    if play_response == 'Y':  # starts the game
        print('Excellent!')
        # Set player_id to 1 for testing
        player_id = 1
        show_status(player_id)  # calls show_status() to output information to user
    else:
        print('Okay, maybe next time.')  # does not start game

    # Gameplay begins 
    while play_response == 'Y':  # if user inputs Y game begins
        soldier_bug = 0
        user_input = input('What do you want to do? (Enter "go North", "go South", "go East", "go West", '
                           'get (item name) or "quit" to quit)\033[1m \n').lower()  # gets user command, converts to bold
        print('\033[0m')  # converts text back to light
        if user_input == 'quit':  # ends game whenever user enters quit command
            print('Thank you for playing!')
            save_player_details(player_id, current_room, inventory_items)
            break
        elif user_input == 'go north':  # calculates user moves using moves function
            current_room = moves('North', current_room, soldier_bug)
            show_status(player_id)  # calls show_status() to output information to user
        elif user_input == 'go south':
            current_room = moves('South', current_room, soldier_bug)
            show_status(player_id)
        elif user_input == 'go west':
            current_room = moves('West', current_room, soldier_bug)
            show_status(player_id)
        elif user_input == 'go east':
            current_room = moves('East', current_room, soldier_bug)
            show_status(player_id)

        # Get item commands
        elif user_input == 'get insect killing granules':
            if 'Insect Killing Granules' not in inventory_items:  # prevents user from adding same item to inventory
                inventory_items.append(get_item(current_room, 'Insect Killing Granules'))  # adds new item to list
                print('Insect Killing Granules added to inventory!')
                show_status(player_id)  # calls show_status() to output information to user
            else:  # outputs that the user already added the item to inventory
                print('Insect Killing Granules are already in your inventory.')
                show_status(player_id)
        elif user_input == 'get horticultural oil':
            if 'Horticultural Oil' not in inventory_items:
                inventory_items.append(get_item(current_room, 'Horticultural Oil'))
                print('Horticultural Oil added to your inventory!')
                show_status(player_id)
            else:
                print('Horticultural Oil is already in your inventory.')
                show_status(player_id)
        elif user_input == 'get insecticidal soap bubbles':
            if 'Insecticidal Soap Bubbles' not in inventory_items:
                inventory_items.append(get_item(current_room, 'Insecticidal Soap Bubbles'))
                print('Insecticidal Soap Bubbles added to your inventory!')
                show_status(player_id)
            else:
                print('Insecticidal Soap Bubbles are already in your inventory.')
                show_status(player_id)
        elif user_input == 'get rubbing alcohol':
            if 'Rubbing Alcohol' not in inventory_items:
                inventory_items.append(get_item(current_room, 'Rubbing Alcohol'))
                print('Rubbing Alcohol added to your inventory!')
                show_status(player_id)
            else:
                print('Rubbing Alcohol is already in your inventory.')
                show_status(player_id)
        elif user_input == 'get white vinegar':
            if 'White Vinegar' not in inventory_items:
                inventory_items.append(get_item(current_room, 'White Vinegar'))
                print('White Vinegar added to your inventory!')
                show_status(player_id)
            else:
                print('White Vinegar is already in your inventory.')
                show_status(player_id)
        elif user_input == 'get mighty spray bottle':
            if 'Mighty Spray Bottle' not in inventory_items:
                inventory_items.append(get_item(current_room, 'Mighty Spray Bottle'))
                print('Mighty Spray Bottle added to your inventory!')
                show_status(player_id)
            else:
                print('Mighty Spray Bottle is already in your inventory.')
                show_status(player_id)
        else:
            print('Please enter a a valid command.')  # if an unrecognized command is input by user
            show_status(player_id)


if __name__ == '__main__':
    main()
